exports.handler = async function(event) {
  const key = process.env.API_FOOTBALL_KEY;

  if (!key) {
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        error: "Missing API_FOOTBALL_KEY environment variable. Add it in Netlify Site settings > Environment variables."
      })
    };
  }

  const type = event.queryStringParameters.type || "fixtures";
  const date = event.queryStringParameters.date || new Date().toISOString().slice(0, 10);
  const league = event.queryStringParameters.league || "";
  const season = event.queryStringParameters.season || "2026";

  let url = "https://v3.football.api-sports.io/fixtures?date=" + encodeURIComponent(date);

  if (type === "live") {
    url = "https://v3.football.api-sports.io/fixtures?live=all";
  }

  if (type === "standings") {
    if (!league) {
      return {
        statusCode: 400,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "Missing league parameter for standings." })
      };
    }
    url = "https://v3.football.api-sports.io/standings?league=" + encodeURIComponent(league) + "&season=" + encodeURIComponent(season);
  }

  if (type === "teams") {
    if (!league) {
      return {
        statusCode: 400,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "Missing league parameter for teams." })
      };
    }
    url = "https://v3.football.api-sports.io/teams?league=" + encodeURIComponent(league) + "&season=" + encodeURIComponent(season);
  }

  try {
    const response = await fetch(url, {
      method: "GET",
      headers: {
        "x-apisports-key": key
      }
    });

    const data = await response.json();

    return {
      statusCode: response.status,
      headers: {
        "Content-Type": "application/json",
        "Cache-Control": type === "live" ? "public, max-age=60" : "public, max-age=300"
      },
      body: JSON.stringify(data)
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: error.message })
    };
  }
};
